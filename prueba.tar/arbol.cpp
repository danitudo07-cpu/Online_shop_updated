#include "arbol.h"

ArbolAVL::ArbolAVL(){
    raiz = nullptr;

}

ArbolAVL::~ArbolAVL(){
    delete raiz;
}

//Getters 

NodoAVL* ArbolAVL::getRaiz(){
    return raiz;
}

void ArbolAVL::RSI(NodoAVL *&a){
    NodoAVL *aux = a->hijoiz;
    a->hijoiz = aux->hijoder;
    aux->hijoder = a;
    
    actualizarAltura(a);
    actualizarAltura(aux);
    a = aux;

}

void ArbolAVL::RSD(NodoAVL *&a){
    NodoAVL *aux = a->hijoder;
    a->hijoder = aux->hijoiz;
    aux->hijoiz = a;
    
    actualizarAltura(a);
    actualizarAltura(aux);
    a = aux;

}

void ArbolAVL::RDI(NodoAVL *&a){
    RSI(a->hijoder);
    RSD(a);
}

void ArbolAVL::RDD(NodoAVL *&a){
    RSD(a->hijoiz);
    RSI(a);
}

void ArbolAVL::actualizarAltura(NodoAVL *a){
    a->altura = 1 + max(altura(a->hijoiz), altura(a->hijoder));
}

void ArbolAVL::insertar_aux(NodoAVL *&a, Producto *ref){
    
    if (a == nullptr){
        a = new NodoAVL();
        a->price = ref->getPrecio();
        a->l.push_back(ref);
        a->numElem++;
    }
    else if (ref->getPrecio() < a->price){
        insertar_aux(a->hijoiz, ref);
        if (altura(a->hijoiz) - altura(a->hijoder) >= 2){
            if (ref->getPrecio() < a->hijoiz->price) RSI(a);
            else RDD(a);
        }
    }
    else if (ref->getPrecio() > a->price){
        insertar_aux(a->hijoder, ref);
        if (altura(a->hijoder) - altura(a->hijoiz) >= 2){
            if (ref->getPrecio() > a->hijoder->price) RSD(a);
            else RDI(a);
        }
    }
    else{
        list<Producto * >::iterator it;
        it = a->l.begin();
        while(it != a->l.end() && (*it)->id() < ref->id()){
            it++;
        }

        /*if( it == a->l.end() || (*it)->id() != ref->id()){
            a->l.insert(it, ref);
            a->numElem++;*/
            a->l.insert(it, ref);
            a->numElem++;
    }
    actualizarAltura(a);

}

void ArbolAVL::insertar(Producto *ref){
    insertar_aux(raiz, ref);
}

int ArbolAVL::altura(NodoAVL *a){
    if (a == nullptr) return -1;
    else return a->altura;
}


// Recorrido en inorden podando las ramas que no pueden contener precios del rango.
// No se crean ArbolAVL temporales: su destructor borraria el subarbol real.
void ArbolAVL::precios_aux(NodoAVL *a, double min, double max, list<Producto*> &res){
    if (a == nullptr) return;
    if (a->price > min) precios_aux(a->hijoiz, min, max, res);
    if (a->price >= min && a->price <= max)
        res.insert(res.end(), a->l.begin(), a->l.end());
    if (a->price < max) precios_aux(a->hijoder, min, max, res);
}

list<Producto*> ArbolAVL::precios(double min, double max){
    list<Producto*> res;
    precios_aux(raiz, min, max, res);
    return res;
}
