#ifndef NODO_AVL
#define NODO_AVL
#include "Producto.h"
#include <list>
using namespace std;    

class NodoAVL {
friend class ArbolAVL;
private:
    double price;
    list<Producto*> l;
    NodoAVL *hijoiz;
    NodoAVL *hijoder;
    int numElem;
    int altura;
public:
    NodoAVL ();
    ~NodoAVL ();
    //int altura ();
    
};

#endif