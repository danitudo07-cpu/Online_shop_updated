#include "Nodo.h"

NodoAVL::NodoAVL(){
    price = 0;
    hijoiz = nullptr;
    hijoder = nullptr;
    numElem = 0;
    altura = 0;
}

NodoAVL::~NodoAVL(){
    delete hijoiz;
    delete hijoder;
}



/*int NodoAVL::altura(){
    int altiz = 0;
    int altde = 0;
    if (hijoiz != nullptr) altiz = hijoiz->altura();
    if (hijoder != nullptr) altde = hijoder->altura();
    return 1 + max(altiz, altde);
}*/



    
