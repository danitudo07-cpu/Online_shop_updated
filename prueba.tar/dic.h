#ifndef _DICCIONARIO
#define _DICCIONARIO
#include "Producto.h"
#include "TablaHash.h"
#include "arbol.h"
#include <list>


class DiccionarioProductos {
 private:
    list<Producto> lista;
    TablaHash tabla;
    int contador;
    ArbolAVL arbol;
 public:
    DiccionarioProductos ();
    void insertar (Producto nuevo);
    void palabras (string palabra);
    // void eliminar (long long id);
    // void producto (long long id);
    void precios(double min, double max);
    static bool comparar_por_id(Producto* a, Producto* b);
 int numElem ()
 {return contador;}
};

#endif
