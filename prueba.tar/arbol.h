#ifndef _ARBOL
#define _ARBOL
#include "Producto.h"
#include "Nodo.h"
#include <list>
using namespace std;



class ArbolAVL {
private:

void insertar_aux(NodoAVL *&a, Producto *ref);
void precios_aux (NodoAVL *a, double min, double max, list<Producto*> &res);
int altura (NodoAVL *a);
void actualizarAltura(NodoAVL *a);

NodoAVL *raiz;

public:

ArbolAVL ();
~ArbolAVL ();
NodoAVL* getRaiz();

void insertar(Producto *ref);

//void eliminar (long long id);



list<Producto*> precios(double min, double max);
void RSI (NodoAVL *&a);
void RSD (NodoAVL *&a);
void RDI (NodoAVL *&a);
void RDD (NodoAVL *&a);
};

#endif