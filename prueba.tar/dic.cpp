#include "dic.h"
#include <sstream>

DiccionarioProductos::DiccionarioProductos(){
    contador = 0;
}

void DiccionarioProductos::insertar(Producto nuevo){
 
    contador++;
    lista.push_back(nuevo);
    Producto* pt = &lista.back();   // puntero al producto guardado, no al parametro
 
    istringstream iss(pt->getNombre() + " " + pt->getDescripcion());
    string w;
    while (iss >> w) {
        tabla.insertar(minusculas(w), pt);   // una entrada por palabra
    }
    arbol.insertar(pt);                       // el arbol es por precio: una sola vez por producto
}


void DiccionarioProductos::palabras(string palabra){

    const list<const Producto*>* l = tabla.consultar(minusculas(palabra));
    int n = 0;
    if (l != NULL) {
        for (list<const Producto*>::const_iterator it = l->begin(); it != l->end(); ++it) {
            n++;
            cout << n << ". ";
            (*it)->mostrar();
        }
    }
    cout << "Total: " << n << " productos" << endl;
}


void DiccionarioProductos::precios(double min, double max){

    list<Producto*> res = arbol.precios(min, max);

    res.sort(DiccionarioProductos::comparar_por_id); // ordena por id, no por precio

    int n = 0;

    for (list<Producto*>::iterator it = res.begin(); it != res.end(); ++it){
        n++;
        cout << n << ". ";
        (*it)->mostrar();
    }

    cout << "Total: " << n << " productos" << endl;
}

bool DiccionarioProductos::comparar_por_id(Producto* a, Producto* b) {
    return a->id() < b->id();
}