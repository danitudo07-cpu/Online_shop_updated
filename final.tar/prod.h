#ifndef _PRODUCTO
#define _PRODUCTO
#include <iostream>
using namespace std;

class Producto {
private:
    unsigned long identificador;
    string nombre;
    string descripcion;
    double precio;

public:
    Producto();
    void leer();
    void mostrar();
    unsigned long mostrar_id();
    double mostrar_precio();
    string getNombre();
    string getDescripcion();
};

#endif