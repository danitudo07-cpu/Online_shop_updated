#ifndef _DICCIONARIO
#define _DICCIONARIO
#include "prod.h"
#include "TablaHash.h"
#include "AVL.h"
#include <sstream>


class DiccionarioProductos {
 private:
 list<Producto> lista;
 TablaHash tabla;
 Arbol<double> miarbol_precios;
 Arbol<unsigned long> miarbol_identificadores;
 int contador;
 public:
 DiccionarioProductos ();
 void insertar (Producto nuevo); 
 void eliminar (long long id); 
 void producto (long long id); 
 void precios (double min,
 double max); 
 void palabras(string palabra); 
 int numElem ()
 {return contador;}
 static bool comparar_por_id(Producto * a, Producto* b);
};

#endif