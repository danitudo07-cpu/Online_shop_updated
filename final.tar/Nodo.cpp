#include "Nodo.h"


template <class T>
Nodo<T>::Nodo(){

    hijo1 = nullptr;
    hijo2 = nullptr;

}

template <class T>
Nodo<T>::~Nodo(){

    delete hijo1;
    delete hijo2;

}

