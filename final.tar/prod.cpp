#include "prod.h"


Producto::Producto()
{
}

void Producto::leer()
{
    
    cin >> identificador;
    cin.ignore(); 

    
    getline(cin, nombre);

    
    getline(cin, descripcion);

   
    cin >> precio;
}

void Producto::mostrar() {
    
    cout << nombre << " (" << identificador << ")" << endl;
    cout << "  " << descripcion << endl;
    cout << "  " << precio << " euros" << endl;
}

unsigned long Producto::mostrar_id(){
    return identificador;
}

double Producto::mostrar_precio(){

    return precio;

}

string Producto::getNombre(){
    return this->nombre;
}

string Producto::getDescripcion(){
    return this->descripcion;
}