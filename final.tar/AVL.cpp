#include "AVL.h"



template <class T>
Arbol<T>::Arbol(){
    raiz = nullptr;
}
template <class T>
Arbol<T>::~Arbol(){

    delete raiz;

}

template <class T>
int Arbol<T>::altura(Nodo<T> * A){
    if (A == nullptr){
        return -1;
    }
    return A->altura;
}


template <class T>
 void Arbol<T>::actualizarAltura(Nodo<T> *a){

    a->altura = 1 + max(altura(a->hijo1), altura(a->hijo2));
    
 }

template <class T>
void Arbol<T>::insertaraux_precios(Nodo<T> * &A, Producto * p ){

    double x = p->mostrar_precio();
    if (A == nullptr){
        A = new Nodo<T>;
        A->clave = x;
        A->hijo2 = A->hijo1 = nullptr;
        A->altura = 0;
        A->l.push_back(p);
    }

    else if ( x < A->clave ){
        insertaraux_precios(A->hijo1, p);
        if ((altura(A->hijo1) - altura(A->hijo2)) > 1){
            if(x < A->hijo1->clave){
            RSI(A);
            }
        
        else{   
            RDI(A);
        }
    }
        
}

    else if( x > A->clave ){
        
        insertaraux_precios(A->hijo2, p);
        if ((altura(A->hijo2) - altura(A->hijo1)) > 1){
            if(x > A->hijo2->clave){
            RSD(A);
            }
        
        else{   
            RDD(A);
        }
    }
       
    }

    else{ //precio igual (colision)
   
    list<Producto * >::iterator it = A->l.begin();
    while(it != A->l.end() && (*it)->mostrar_id() < p->mostrar_id()){
        it++;
    }

    if( it == A->l.end() || (*it)->mostrar_id() != p->mostrar_id()){
        A->l.insert(it, p);
    }
}

    if (A != nullptr) {
        actualizarAltura(A);
    }

}
 
template <class T>
 void Arbol<T>::insertar_precios(Producto * p ){
        insertaraux_precios(raiz, p);
    }

template <class T>
void Arbol<T>::insertaraux_id(Nodo<T> * & A, Producto * p){
 double x = p->mostrar_id();
    if (A == nullptr){
        A = new Nodo<T>;
        A->clave = x;
        A->hijo2 = A->hijo1 = nullptr;
        A->altura = 0;
        A->l.push_back(p);
    }

    else if ( x < A->clave ){
        insertaraux_id(A->hijo1, p);
        if ((altura(A->hijo1) - altura(A->hijo2)) > 1){
            if(x < A->hijo1->clave){
            RSI(A);
            }
        
        else{   
            RDI(A);
        }
    }
        
}

    else if( x > A->clave ){
        
        insertaraux_id(A->hijo2, p);
        if ((altura(A->hijo2) - altura(A->hijo1)) > 1){
            if(x > A->hijo2->clave){
            RSD(A);
            }
        
        else{   
            RDD(A);
        }
    }
       
    }

    if (A != nullptr) {
        actualizarAltura(A);
    }
}

template <class T>
void Arbol<T>::insertar_id(Producto * p){
    insertaraux_id(raiz, p);
}


template <class T>
void Arbol<T>::eliminar_nodo(Nodo<T> * & A, T clave){
    
    if(A == nullptr) return;

        if(A->clave > clave){
            eliminar_nodo(A->hijo1, clave);
        } 
        else if(A->clave < clave){
            eliminar_nodo(A->hijo2, clave);
        }
        else{
            if(A->hijo1 == nullptr || A->hijo2 == nullptr){
                Nodo<T> * borrar = A;
                if(A->hijo1 == nullptr){
                    A = A->hijo2;
                }
                else{
                    A = A->hijo1;
                }

                borrar->hijo1 = nullptr;
                borrar->hijo2 = nullptr;

                delete borrar;
            }
        

        //ARRIBA CASOS DONDE HAY 1  O 0 HIJOS
        //AHORA CASOS 2 HIJOS
        else{ //se busca el nodo con el valor minimo del subarbol derecho
            Nodo<T> * aux = A->hijo2;
            while(aux->hijo1 != nullptr){
                aux = aux->hijo1;
            }
            A->clave = aux->clave;
            A->l = aux->l;
            eliminar_nodo(A->hijo2, aux->clave); //Sse elimina el nodo minimo 
            //del subarbol derecho recursivamente
        }
    }

        if(A != nullptr){
            actualizarAltura(A);

            if(altura(A->hijo1) - altura(A->hijo2) > 1){
                if(altura(A->hijo1->hijo1) >= altura(A->hijo1->hijo2)){
                    RSI(A);
                }
                else{
                    RDI(A);
                }
            }
            else if(altura(A->hijo2) - altura(A->hijo1) > 1){
                if(altura(A->hijo2->hijo2) >= altura(A->hijo2->hijo1)){
                    RSD(A);
                }
                else{
                    RDD(A);
                }
            }


        }

        

}


template<class T>
void Arbol<T>::eliminar_id_aux(Nodo<T> * & A, T clave){

        eliminar_nodo(A, clave);

}


template<class T>
void Arbol<T>::eliminar_id(T clave){
    eliminar_id_aux(raiz, clave);
}


template<class T>
void Arbol<T>::eliminar_precio_aux(Nodo<T> * & A, Producto * p ){
 
    if(A == nullptr) return;
    double precio = p->mostrar_precio();

        if(A->clave > precio){
            eliminar_precio_aux(A->hijo1, p);
        } 
        else if(A->clave < precio){
            eliminar_precio_aux(A->hijo2, p);
        }
        else{

            list<Producto * >::iterator it = A->l.begin();
            while(it != A->l.end() && (*it)->mostrar_id() < p->mostrar_id()){
                it++;
            }
            if(it != A->l.end() && (*it)->mostrar_id() == p->mostrar_id()){
                A->l.erase(it);
            }
            if(A->l.empty()){

            if(A->hijo1 == nullptr || A->hijo2 == nullptr){
                Nodo<T> * borrar = A;
                if(A->hijo1 == nullptr){
                    A = A->hijo2;
                }
                else{
                    A = A->hijo1;
                }

                borrar->hijo1 = nullptr;
                borrar->hijo2 = nullptr;

                delete borrar;
            }
        

        //ARRIBA CASOS DONDE HAY 1  O 0 HIJOS
        //AHORA CASOS 2 HIJOS
            else{ //se busca el nodo con el valor minimo del subarbol derecho
            Nodo<T> * aux = A->hijo2;
            while(aux->hijo1 != nullptr){
                aux = aux->hijo1;
            }
            A->clave = aux->clave;
            A->l = aux->l;
            eliminar_nodo(A->hijo2, aux->clave); //Sse elimina el nodo minimo 
            //del subarbol derecho recursivamente
        }
    }
}

        if(A != nullptr){
            actualizarAltura(A);

            if(altura(A->hijo1) - altura(A->hijo2) > 1){
                if(altura(A->hijo1->hijo1) >= altura(A->hijo1->hijo2)){
                    RSI(A);
                }
                else{
                    RDI(A);
                }
            }
            else if(altura(A->hijo2) - altura(A->hijo1) > 1){
                if(altura(A->hijo2->hijo2) >= altura(A->hijo2->hijo1)){
                    RSD(A);
                }
                else{
                    RDD(A);
                }
            }


        }


}

template<class T>
void Arbol<T>::eliminar_precio(Producto * p){
    eliminar_precio_aux(raiz, p);
}


template <class T>
void Arbol<T>::precios_aux(Nodo<T> * a, double min, double max, list<Producto*> &res){

    if (a == nullptr) return;
    if (a->clave > min) precios_aux(a->hijo1, min, max, res);
    if (a->clave >= min && a->clave <= max)
        res.insert(res.end(), a->l.begin(), a->l.end());
    if (a->clave < max) precios_aux(a->hijo2, min, max, res);


}
template <class T>
 list<Producto*> Arbol<T>::precios (double min, double max){
    list<Producto * > res;
    precios_aux(raiz, min, max, res);
    return res;    
  
}

template <class T>
void Arbol<T>::consulta_clave_aux(Nodo<T> * a, T clave, list <Producto *> &res){

    if (a == nullptr) return;
    if (a->clave > clave) consulta_clave_aux(a->hijo1, clave, res);
    if (a->clave == clave){
        
    /*    
        list<Producto*>::iterator it = a->l.begin();
        res.push_back((*it)); 
    */
    res = a->l;
    }
        if (a->clave < clave) consulta_clave_aux(a->hijo2, clave, res);

}

template <class T>
list<Producto *> Arbol<T>::consulta_clave(T clave){
    list<Producto * > res;
    consulta_clave_aux(raiz, clave , res);
    return res;  
}


template <class T>
 void Arbol<T>::RSI (Nodo<T> *&A){
    Nodo<T> * aux = A->hijo1;
    A->hijo1 = aux->hijo2;
    aux->hijo2 = A;
    actualizarAltura(A);
    actualizarAltura(aux);
    A = aux;
 }
template <class T>
 void Arbol<T>::RDI (Nodo<T> *&A){
    RSD(A->hijo1);
    RSI(A);
 }
 template <class T>
 void Arbol<T>::RSD (Nodo<T> *&A){
    Nodo<T> * aux = A->hijo2;
    A->hijo2 = aux->hijo1;
    aux->hijo1 = A;
    actualizarAltura(A);
    actualizarAltura(aux);
    A = aux;
 }
 template <class T>
 void Arbol<T>::RDD (Nodo<T> *&A){
    RSI(A->hijo2);
    RSD(A);
 }
 