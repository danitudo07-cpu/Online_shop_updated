#ifndef _INTERPRETE
#define _INTERPRETE
#include "dic.h"
#include "prod.h"

void procesar_insertar();
void procesar_palabras();
void procesar_precios();
void procesar_eliminar();
void procesar_producto();
void Interprete (string comando);


#endif