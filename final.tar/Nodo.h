#ifndef _NodoAVL
#define _NodoAVL
#include "prod.h"
#include <list>


template <class T>
class Nodo {
template <class U>
 friend class Arbol;
 private:
 Nodo* hijo1;
 Nodo* hijo2;
 list<Producto * > l;
 T clave;
 int altura;

 
 public:
 Nodo();
 ~Nodo ();

};

#include "Nodo.cpp"
#endif
