#include "dic.h"

string minusculas(string c) {
    string s;
    for (size_t i = 0; i < c.length(); i++) {
        unsigned char a = c[i];
        if (a >= 'A' && a <= 'Z') s += (char)(a + 32);
        else if (a == 0xC3 && i + 1 < c.length()) {
            unsigned char n = c[++i];
            s += (char)0xC3;
            if (n==0x81||n==0x89||n==0x8D||n==0x93||n==0x9A||n==0x9C||n==0x91) s += (char)(n + 0x20);
            else s += (char)n;
        } else s += c[i];
    }
    return s;
}


 DiccionarioProductos::DiccionarioProductos(){

    contador=0;

 }
 void DiccionarioProductos::insertar (Producto nuevo){

   
   list<Producto>::iterator it = lista.begin();
   while(it != lista.end() && it->mostrar_id() < nuevo.mostrar_id()){
      it++;
   }

   if(it == lista.end() || it->mostrar_id() != nuevo.mostrar_id()){
      contador++;
      it = lista.insert(it, nuevo);

   Producto * pt = &(*it);
    istringstream iss(pt->getNombre() + " " + pt->getDescripcion());
    string w;
    while (iss >> w) {
      tabla.insertar(minusculas(w), pt);
    }
   
    miarbol_precios.insertar_precios(pt);
    miarbol_identificadores.insertar_id(pt);
   
   }

 }
 void DiccionarioProductos::eliminar (long long id){

   
    list<Producto*> res = miarbol_identificadores.consulta_clave(id);
    
    if(res.size() != 0){
    
    Producto * p = res.front();


      //eliminar de la tabla hash...
     istringstream iss(p->getNombre() + " " + p->getDescripcion());

        string w;
        while(iss >> w){
            tabla.eliminar(minusculas(w), p);
        }


      //eliminar de los arboles...
    miarbol_precios.eliminar_precio(p);
    miarbol_identificadores.eliminar_id(id);
        
    //eliminar de la lista de productos...
    //si no, se queda un puntero colgando en la tabla hash y en los arboles
    list<Producto>::iterator it = lista.begin();
   while(it != lista.end() && it->mostrar_id() < (*p).mostrar_id()){
      it++;
   }
   if(it != lista.end() && it->mostrar_id() == (*p).mostrar_id()){
      contador--;
      it = lista.erase(it);
   } // SE elimina primero de la tabla hash, luego de los arboles y finalmente de la lista de productos   }    
  }
 }
 
 void DiccionarioProductos::producto (long long id){


   int esta=0;

   list<Producto*> res = miarbol_identificadores.consulta_clave(id);
   list<Producto*>::iterator it = res.begin();
   if(res.size() == 1 && (*it)->mostrar_id() == id){
      esta = 1;
      cout << esta << ". ";
      (*it)->mostrar();
   }
   cout <<"Total: " <<  esta << " productos" << endl;

 }

bool DiccionarioProductos::comparar_por_id(Producto* a, Producto* b) {
    return a->mostrar_id() < b->mostrar_id();
}


void DiccionarioProductos::precios(double min, double max){

    list<Producto*> res = miarbol_precios.precios(min, max);

    res.sort(DiccionarioProductos::comparar_por_id); // ordena por id, no por precio

    int n = 0;

    for (list<Producto*>::iterator it = res.begin(); it != res.end(); ++it){
        n++;
        cout << n << ". ";
        (*it)->mostrar();
    }

    cout << "Total: " << n << " productos" << endl;
}

void DiccionarioProductos::palabras(string palabra){
   
   
   list<Producto*>* l = tabla.consultar(minusculas(palabra));
    int n = 0;
    if (l != nullptr){
      list<Producto*>::iterator it;
      it = l->begin();
      
      while( it != l->end()) {
         n++;
         cout << n << ". ";
         (*it)->mostrar();
         it++;
      }
   
    }
    cout << "Total: " << n << " productos" << endl;
}
