#ifndef _TABLA_HASH
#define _TABLA_HASH
#include "prod.h"
#include <list>




class TablaHash {
 private:
 class Par{
    string Palabra;
    list<Producto*> l;
    friend class TablaHash;
};


 list<Par> * T;
 int nElem;
 unsigned long fhash(string palabra);
 void reestructurar(); //dinamico
 int B; //Numero cubetas (dinamico)

 public:
 TablaHash ();
 ~TablaHash ();
 void insertar (string palabra, Producto *nuevo);
 void eliminar (string palabra, Producto *p);
 list<Producto*>* consultar (string nombre); 
 int numElem (void) { return nElem; }
 int nuevoB();
};


#endif