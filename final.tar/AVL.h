#ifndef _AVL
#define _AVL
#include "Nodo.h"
#include <list>

template <class T>
class Arbol {
 private:
 Nodo<T> *raiz;
void insertaraux_precios(Nodo<T> * & a, Producto * p );
void insertaraux_id(Nodo<T> * & a, Producto * p);
void precios_aux(Nodo<T> * a, double min, double max, list <Producto *> &res); 
void consulta_clave_aux(Nodo<T> * a, T clave, list <Producto *> &res);
void eliminar_nodo(Nodo<T> * & A, T clave);
void eliminar_precio_aux(Nodo<T> * & A, Producto * p );
void eliminar_id_aux(Nodo<T> * & A, T clave);
Nodo<T> * buscar_desbalanceado(Nodo<T> * A);
public:
 Arbol();
 ~Arbol ();
 int altura(Nodo<T> * A);
 void insertar_precios(Producto * p);
 void insertar_id(Producto * p);
 void eliminar_id(T clave);
 void eliminar_precio(Producto * p);
 list<Producto *> precios (double min, double max);
 list<Producto *> consulta_clave(T clave);
 void RSI (Nodo<T> *&A);
 void RDI (Nodo<T> *&A);
 void RSD (Nodo<T> *&A);
 void RDD (Nodo<T> *&A);
 void actualizarAltura(Nodo<T> * a);
 

};

#include "AVL.cpp"
#endif