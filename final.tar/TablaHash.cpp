#include "TablaHash.h"
#ifndef B_INCIAL
#define B_INICIAL 101
#endif

TablaHash::TablaHash(){

    T = new list<Par>[B_INICIAL];
    nElem = 0;
    B = B_INICIAL;


}

TablaHash::~TablaHash(){ delete[] T; }

unsigned long TablaHash::fhash(string palabra){
//suma posicional parecido a sdbm
  
  int base = 65599;
  unsigned int res = 0;
  for (int i = 0; i < palabra.length(); i++){
    res *= base;
    res += palabra[i];
  } 

  return res%B;

}

int TablaHash::nuevoB(){

  //busca el primo mas proximo a 2B+1

  int newB = this->B * 2 + 1;
  bool seguir = true;

  while(seguir){

  int i = 3;
  while (i <= newB/i && newB%i != 0){ // i <= sqrt(newB) <-> i*i <= newB <-> i <= newB/i
    i += 2;
  }

  if(newB%i == 0){
    newB += 2;
  }

  else{
    seguir = false;
  }

}

  return newB;

}


void TablaHash::reestructurar(){
 int nuevoB = this->nuevoB();
    list<Par>* nueva = new list<Par>[nuevoB];
    int viejoB = B;
    list<Par>* vieja = T;

    B = nuevoB;                       // dispersion() ya usa el tamaño nuevo
    for (int i = 0; i < viejoB; i++) {
        while (!vieja[i].empty()) {
            
        unsigned long pos = fhash(vieja[i].front().Palabra);

        list<Par>::iterator it = nueva[pos].begin();

        while (it != nueva[pos].end() &&
               it->Palabra < vieja[i].front().Palabra) {
            it++;
        }

        nueva[pos].splice(it, vieja[i], vieja[i].begin());
    }
    }
    T = nueva;
    delete[] vieja;

}


void TablaHash::insertar(string palabra, Producto * nuevo){

    unsigned int indice = fhash(palabra);

    list<Par>::iterator it;
    it = T[indice].begin(); // iterador

    while (it != T[indice].end() && (*it).Palabra < palabra){
        it++;      //recorre la lista
    }

    if ( it == T[indice].end() || (*it).Palabra != palabra ){ //si no esta la palabra en la lista de pares, se incluye
    if(nElem +1 > 1.5*B ){
      reestructurar();
      insertar(palabra, nuevo);
      return;
    }
      Par par_nuevo;
    par_nuevo.Palabra = palabra;
    list<Producto*> lista_nueva;
    lista_nueva.push_back(nuevo); 
    par_nuevo.l = lista_nueva;
    T[indice].insert(it, par_nuevo); 
    nElem++;


    }

    //if ((*it).Palabra == palabra) 
    else{
    
    list<Producto *>::iterator it2;
    it2 = (*it).l.begin();
    while ( it2 != (*it).l.end() && (*it2)->mostrar_id() < nuevo->mostrar_id() ){
      it2++;
    }
    if(it2 == it->l.end() || (*it2)->mostrar_id() != nuevo->mostrar_id() ){
      //aqui en la lista de punteros a productos no se ha encontrado una coincidencia
      (*it).l.insert(it2, nuevo);
    }
    }


}

list<Producto*>* TablaHash::consultar(string nombre){
  unsigned int indice = fhash(nombre);


  
  list<Par>::iterator it;
  it = T[indice].begin();
  while( it != T[indice].end() && (*it).Palabra < nombre ){
    it++;
  }

  if ( it  == T[indice].end() || (*it).Palabra != nombre){
    return nullptr;
  }

  return &it->l;

}

void TablaHash::eliminar(string palabra, Producto * p){
  unsigned int indice = fhash(palabra);

  list<Par>::iterator it;
  it = T[indice].begin();
  while( it != T[indice].end() && (*it).Palabra < palabra ){
    it++;
  }

  if ( it  != T[indice].end() && (*it).Palabra == palabra){
    
  list<Producto *>::iterator it2;
  it2 = (*it).l.begin();
  while ( it2 != (*it).l.end() && (*it2)->mostrar_id() < p->mostrar_id() ){
    it2++;
  }
  if(it2 != it->l.end() && (*it2)->mostrar_id() == p->mostrar_id() ){
    (*it).l.erase(it2);
    if((*it).l.empty()){
      T[indice].erase(it);
      nElem--;
    }
  }
}
}