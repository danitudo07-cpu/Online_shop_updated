#include "interprete.h"

Producto actual;
DiccionarioProductos midic = DiccionarioProductos();


void procesar_insertar(){
        actual.leer ();
        midic.insertar(actual);
        cout << midic.numElem() << " productos" << endl;
}

void procesar_palabras(){
    string c;
    cout << "palabras ";
    getline(cin >> ws, c); //consume los espacios en blanco iniciales y luego lee la linea completa
    cout << c << endl;
    istringstream iss(c);
    while (iss >> c) { //iss es el flujo de entrada que contiene la linea completa, y se va extrayendo palabra por palabra
        midic.palabras(c); // lee palabra por palabra y llama a la funcion palabras de DiccionarioProductos
    }
}
void procesar_precios(){

    double p1, p2;
    cout << "precios ";
    cin >> p1 >> p2;
    cout << p1  << " "  << p2 << endl;
    midic.precios(p1,p2);
}

void procesar_eliminar(){
    long long c;
    cin >> c;
    midic.eliminar(c);
    cout << midic.numElem() << " productos" << endl;
}
void procesar_producto(){
    long long c;
    cout << "producto ";
    cin >> c;
    cout << c << endl;
    midic.producto(c);
    

}

void Interprete (string comando)
{
 if (comando=="insertar") {procesar_insertar();}
 else if (comando=="palabras"){procesar_palabras();}
 else if (comando=="precios") {procesar_precios();}
 else if (comando=="eliminar") {procesar_eliminar();}
 else if (comando=="producto") {procesar_producto();}
 }
